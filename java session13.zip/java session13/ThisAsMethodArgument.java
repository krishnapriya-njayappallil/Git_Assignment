public class ThisAsMethodArgument {
 
	// This is an Example for PassByValue
	private static void printLine(int noOfTimes) {
		for (int i = 0; i < noOfTimes; i++) {
			System.out.print("--");
		}
		noOfTimes = 100;
		System.out.println();
	}
 
	// This is an Example for PassByReference
	public static void displayStudentDetails(Trainee argumentObj) {
		printLine(20);
		System.out.println("From ThisAsMethodArgument Class");
		printLine(20);
		System.out.println(argumentObj.toString());
		printLine(20);
		System.out.println("Trainee Id:" + "\t" + argumentObj.getTraineeId());
		System.out.println("Trainee Name:" + "\t" + argumentObj.getTraineeName());
		System.out.println("Trainee Joining Location:" + "\t" + argumentObj.getJoiningLocation());
		System.out.println("Trainee Preferred Location:" + "\t" + argumentObj.getPreferredLocation());
		System.out.println("Trainee Id:" + "\t" + argumentObj.getTraineeId());
		argumentObj.setJoiningLocation("Banglore");
		argumentObj.setPreferredLocation("Chennai");
		printLine(20);
	}
 
}