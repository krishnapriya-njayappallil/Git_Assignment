public class Trainee{
	private int traineeId;
	private String traineeName;
	private String traineePwd;
	private String preferredLocation;
	private String joiningLocation;
	
public Trainee(int traineeId,String traineeName,String traineePwd,String preferredLocation,String joiningLocation){
	this(traineeId,traineeName,traineePwd);
	System.out.println("I am from all parametes cons:"+this.hashCode());
	this.preferredLocation = preferredLocation;
	this.joiningLocation = joiningLocation;
}

public Trainee(){
	System.out.println("From Default Cons:"+this.hashCode());
	joiningLocation = "Trivandrum";
	preferredLocation = "Hyderabad";
}

public Trainee(int traineeId,String traineeName,String traineePwd){
this();
System.out.println("3 Args Cons:"+this.toString());
this.traineeId=traineeId;
this.traineeName=traineeName;
this.traineePwd=traineePwd;
}
private Trainee returnCurrentInstance(){
	return this;
}

public void sendTraineeDetails(){
	Trainee traineeObj=returnCurrentInstance();
	ThisAsMethodArgument.displayStudentDetails(traineeObj);
}
public String toString(){
	return "Trainee(traineeID="+traineeId+", traineename="+traineeName+", traineePwd"+traineePwd+", preferredLocation="+preferredLocation;
}

