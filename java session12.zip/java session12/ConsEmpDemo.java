public class ConsEmpDemo{
	public static void main(String[] args){
		System.out.println("I am from main method");
		Employee employee = new Employee();
		System.out.println(employee);

		Employee employee2 = new Employee();
		System.out.println(employee2);

		Employee employee3= new Employee(1001,"Moksha",12000,2000,20,"Jambi@123");
		System.out.println(employee3);

		Employee employee4=new Employee(employee3);
		System.out.println(employee4);

		employee=null;
		employee2=null;
		employee3=null;
		employee4=null;
		System.gc();
		System.out.println("End of Main Method");
	}
}