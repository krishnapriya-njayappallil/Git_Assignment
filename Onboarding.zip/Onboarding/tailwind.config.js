/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
      "./src/**/*.{js,jsx,ts,tsx}",
    ],
    theme: {
      extend: {
        screens: {
          
          'sm': '426px',
  
          
          'md': '769px',
  
          
          'lg': '1024px',
  
          
          'xl': '1440px',
  
        },
        colors: {
          primary: "var(--color-primary)",
          secondary: "var(--color-secondary)"
        },
      },
    },
    plugins: [],
  }