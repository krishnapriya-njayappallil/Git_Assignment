import React from "react";

const Home = () => {
  return (
    <div className="flex justify-center items-center h-screen bg-blue-500 flex-col">
      <h1 className="text-4xl text-white font-bold">Hello, Tailwind CSS!</h1>
      <a href="/redux-demo" className="text-white underline" >redux-demo</a>
    </div>
  );
};

export default Home;
