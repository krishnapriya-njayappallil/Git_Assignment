import React from "react";
import { useDispatch, useSelector } from "react-redux";
import {
    increment
} from "../redux/slices/countSlice";
const Demo = () => {
    const dispatch = useDispatch();
    const {
       count
      } = useSelector((state) => state.count);
    const onClickHandler=()=>{
        dispatch(increment(1))
    }
  return (
    <div className="flex justify-center items-center h-screen bg-blue-500 flex-col">
      <button className="text-white border p-4 bg-[var(--color-primary)]" onClick={onClickHandler}>Add</button>
      <p className="text-white">{count}</p>
    </div>
  );
};

export default Demo;
