import { configureStore } from "@reduxjs/toolkit";
import countSlice from "./slices/countSlice"

const store = configureStore({
  reducer: {
    count:countSlice
  },
});

export default store;
