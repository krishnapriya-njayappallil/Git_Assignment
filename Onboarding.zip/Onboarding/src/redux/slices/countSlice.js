import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    count:null
};

const countSlice = createSlice({
    name: 'count',
    initialState,
    reducers: {
        increment: (state, action) => {
            state.count = state.count+action.payload;
        }
    }
});

export const {
    increment
} = countSlice.actions;

export default countSlice.reducer;
