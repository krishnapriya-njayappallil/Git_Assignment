import { Provider } from 'react-redux';
import store from './redux/store';
import Path from './routes/Path';
import './App.css';

function App() {
  return (
    <Provider store={store}>
      <Path />
    </Provider>
  );
}

export default App;
