import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Home from "../pages/Home";
import Demo from "../pages/Demo";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/redux-demo",
    element: <Demo />
  }
  
]);
 
function Path() {
  return <RouterProvider router={router} />;
}


export default Path;
