let userList = []; 
const apiUrlGiven = "https://jsonplaceholder.typicode.com/users"; 
 
function isValidEmail(email) { 
 const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/; 
 return emailPattern.test(email); 
} 
 
function addUserToList() { 
 return new Promise((resolve, reject) => { 
 const username = document.getElementById('username').value; 
 const email = document.getElementById('email').value; 
 
 console.log('Attempting to add user: ', username, email); 
 
 // Validate the username, email, and password fields 
 if (username == ""  ) { 
  
 console.log("Failed to add user: Username is empty."); 
 reject("Username  is required!"); 
 return; 
 } 
 
 if (email =="" || !isValidEmail(email)) { 
  
 console.log("Failed to add user: Invalid email address."); 
 reject("Please enter a valid email address!"); 
 return; 
 } 
 setTimeout(() => { 
 // Check if email already exists in the list 
 for (let i = 0; i < userList.length; i++) { 
 if (userList[i].email ==email) { 
 console.log("Failed to add user: Email already exists."); 
 reject("Email already exists!"); 
 return; 
 } 
 } 
 
 // Add the user to the list 
 userList.push({ username, email }); 
 console.log('User added successfully:', username, email);  
 resolve("User added successfully!"); 
 }, 1000); // Simulated delay 
 }); 
} 
 
function displayUserList() { 
 const userListElement = document.getElementById('userList'); 
 userListElement.innerHTML = ''; // Clear existing list 
 
 const titleRow = document.createElement('div'); 
 titleRow.innerHTML = '<h3>Username----------------Email</h3>'; // Title with a simple divider 
 userListElement.appendChild(titleRow); 
 
 userList.forEach(user => { 
 const listItem = document.createElement('li'); 
 listItem.textContent = `${user.username} --- ${user.email}`; 
 userListElement.appendChild(listItem); 
 }); 
} 
 
// Function to remove a user 
function removeUser(email) { 
 if (email =="" || !isValidEmail(email)) { 
 alert('Please enter a valid email address!'); 
 console.log("Failed to add user: Invalid email address."); 
 return; 
} 
 const index = userList.findIndex(user => user.email == email); 
 if (index != -1) { 
 userList.splice(index, 1);  // Remove user from the list 
 console.log('User removed:', email); 
 } else { 
 alert('User not found with email',email); 
 console.log('User not found with email:', email); 
 } 
} 
 
// Function to fetch users from the API and add to the user list 
async function fetchUsersFromAPI() { 
 try { 
 const response = await fetch(apiUrlGiven); 
 if (!response.ok) { 
 throw new Error("Failed to fetch users."); 
 } 
 
 const users = await response.json(); 
 
 // Add the fetched users to the userList 
 users.forEach(user => { 
 const userToAdd = { 
 username: user.name, 
 email: user.email 
 }; 
 userList.push(userToAdd);  // Adding user to the list 
 }); 
 
 // Display the updated user list 
 displayUserList(); 
 
 } catch (error) { 
 console.error("Error fetching users:", error); 
 } 
} 
 
document.getElementById('addUserForm').addEventListener('submit', function(event) { 
 event.preventDefault(); // Prevent form from submitting the traditional way 
 addUserToList() 
 .then(successMessage => { 
 alert(successMessage); 
 displayUserList(); // Update the list on the page 
 }) 
 .catch(errorMessage => { 
 alert(errorMessage); 
 }); 
}); 
 
document.getElementById('removeUserButtton').addEventListener('click', () => { 
 const emailToRemove = document.getElementById('removeEmail').value; 
 removeUser(emailToRemove); 
 displayUserList(); 
}); 
 
// Event listener for fetching all users (optional, if needed) 
document.getElementById('fetchUsersBtn').addEventListener('click',  () => { 
fetchUsersFromAPI(); 
}); 
