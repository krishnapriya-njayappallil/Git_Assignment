document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Clear all previous error messages
    document.querySelectorAll('.error-message').forEach(error => error.textContent = '');

    let isValid = true;

    // Full Name validation
    const fullName = document.getElementById('fullName');
    if (fullName.value.trim() === '') {
        isValid = false;
        document.getElementById('fullNameError').textContent = 'Full Name is required.';
    }

    // Date of Birth validation
    const dob = document.getElementById('dob');
    if (dob.value.trim() === '') {
        isValid = false;
        document.getElementById('dobError').textContent = 'Date of Birth is required.';
    }

    // Gender validation
    const gender = document.querySelector('input[name="gender"]:checked');
    if (!gender) {
        isValid = false;
        document.getElementById('genderError').textContent = 'Please select a gender.';
    }

    // Role validation
    const roles = document.querySelectorAll('input[name="role"]:checked');
    if (roles.length === 0) {
        isValid = false;
        document.getElementById('roleError').textContent = 'Please select at least one role.';
    }

    // Citizenship validation
    const citizenship = document.getElementById('citizenship');
    if (citizenship.value.trim() === '') {
        isValid = false;
        document.getElementById('citizenshipError').textContent = 'Please select your country of citizenship.';
    }

    // Address validation
    const address = document.getElementById('address');
    if (address.value.trim() === '') {
        isValid = false;
        document.getElementById('addressError').textContent = 'Address is required.';
    }

    // Pin Code validation
    const pincode = document.getElementById('pincode');
    if (pincode.value.trim() === '' || isNaN(pincode.value)) {
        isValid = false;
        document.getElementById('pincodeError').textContent = 'Valid Pin Code is required.';
    }

    // Degree validation
    const degree = document.getElementById('degree');
    if (degree.value.trim() === '') {
        isValid = false;
        document.getElementById('degreeError').textContent = 'Degree is required.';
    }

    // Skills validation
    const skills = document.getElementById('skills');
    if ([skills.selectedOptions].length === 0) {
        isValid = false;
        document.getElementById('skillsError').textContent = 'Please select at least one skill.';
    }
    
    // If the form is valid, submit it
    if (isValid) {
        alert('Form submitted successfully!');
        
    }
});