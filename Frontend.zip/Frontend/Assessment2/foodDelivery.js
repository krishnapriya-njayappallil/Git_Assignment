const foodItems = [
    { id: 1, name: "Pizza", rating: 4.5, price: 250, image: "images/pizza.jpg" },
    { id: 2, name: "Burger", rating: 4.2, price: 150, image: "images/burger.jpg" },
    { id: 3, name: "Pasta", rating: 4.7, price: 200, image: "images/pasta.jpg" },
    { id: 4, name: "Salad", rating: 4.3, price: 100, image: "images/salad.jpg" }
];
async function fetchFoodItems() {
    return new Promise((resolve) => {
        setTimeout(() => resolve(foodItems), 1000);
    });
}

async function renderFoodDeliveryHomepage() {
    const foodItems = await fetchFoodItems();
    

    
    const foodItemsContainer = document.getElementById('food-items');

    const selectedItems = [];

    foodItems.forEach(item => {
        const foodCard = document.createElement('div');
        foodCard.className = 'food-card';

        const img = document.createElement('img');
        img.src = item.image;
        img.alt = item.name;
        img.className = 'food-image';

        const name = document.createElement('h2');
        name.textContent = item.name;

        const rating = document.createElement('p');
        rating.textContent = `Rating: ${item.rating}`;

        const price = document.createElement('p');
        price.textContent = `Price: ₹${item.price}`;

        const selectButton = document.createElement('button');
        selectButton.className = 'select-item';
        selectButton.textContent = 'Select';
        selectButton.dataset.id = item.id;

        selectButton.addEventListener('click', () => {
            if (!selectedItems.includes(item)) {
                selectedItems.push(item);
                alert(`${item.name} added to your order.`);
            }
        });

        foodCard.appendChild(img);
        foodCard.appendChild(name);
        foodCard.appendChild(rating);
        foodCard.appendChild(price);
        foodCard.appendChild(selectButton);

        foodItemsContainer.appendChild(foodCard);
    });

    

   
    
   
   
   takeOrderButton=document.getElementById("take-order");

   
    
    takeOrderButton.addEventListener('click', () => {
       // console.log(selectedItems);
        localStorage.setItem('selectedItems', JSON.stringify(selectedItems));
        window.location.href = "placeOrder.html";
        
        
        // Navigate to the order page or render order summary.
    });
    
}



renderFoodDeliveryHomepage();