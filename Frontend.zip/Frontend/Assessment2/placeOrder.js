const selectedItems = JSON.parse(localStorage.getItem('selectedItems')) || [];
    document.addEventListener('DOMContentLoaded', () => {
        if (selectedItems.length === 0) {
            alert('No items selected!');
            window.location.href = 'foodDelivery.html'; // Redirect back if no items
            return;
        }
    
        renderOrdersPage(selectedItems);
    });

function renderOrdersPage(selectedItems) {
   
    
    
    const orderSummary =document.getElementById('order-summary');

    let grandTotal = 0;

    selectedItems.forEach(item => {
        const orderItem = document.createElement('div');
        orderItem.className = 'order-item';

        const name = document.createElement('h2');
        name.textContent = item.name;

        const price = document.createElement('p');
        price.textContent = `Price: ₹${item.price}`;

        grandTotal += item.price;

        orderItem.appendChild(name);
        orderItem.appendChild(price);
        orderSummary.appendChild(orderItem);
    });

    const total = document.getElementById('grand-total');
    total.textContent = `Grand Total: ₹${grandTotal}`;

    const placeOrderButton = document.getElementById('place-order');

    placeOrderButton.addEventListener('click', () => {
        alert('Order placed successfully.');
      
    });

    const loginButton = document.getElementById('login-page');

    loginButton.addEventListener('click', () => {
        window.location.href="loginPage.html";
      
    });

   
}
