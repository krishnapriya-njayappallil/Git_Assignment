// Define the JSON data (in a real-world app, this would be a separate file)


// Simulate fetching data from JSON file


// Render login page
function renderLoginPage() {
    
    

   

    

    document.getElementById('login-form').addEventListener('submit', (event) => {
        event.preventDefault();
        window.location.href = "foodDelivery.html";
       
    });
}

// Render food delivery homepage


// Render orders page


// Initialize the app
renderLoginPage();
