package com.ECommerceProject.UserManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ECommerceProject.UserManagement.controller.UserController;
import com.ECommerceProject.UserManagement.entity.User;
import com.ECommerceProject.UserManagement.entity.UserAddress;
import com.ECommerceProject.UserManagement.enums.Role_User;
import com.ECommerceProject.UserManagement.repository.IUserAddressRepository;
import com.ECommerceProject.UserManagement.repository.IUserRepository;
import com.ECommerceProject.UserManagement.request.UserAddressRequest;
import com.ECommerceProject.UserManagement.request.UserRequest;
import com.ECommerceProject.UserManagement.response.UserAddressResponse;
import com.ECommerceProject.UserManagement.response.UserResponse;
import com.ECommerceProject.UserManagement.service.UserService;
import com.ECommerceProject.UserManagement.service.UserServiceImpl;
import com.ECommerceProject.UserManagement.util.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;


public class UserControllerTest {

	@Mock
    private IUserRepository userRepository;
	
	@Mock
	private IUserAddressRepository userAddressRepo;

    @InjectMocks
    private UserServiceImpl userService;
    
    
    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetUserById() {
        User user = new User();
        user.setUserId(1);
        user.setUserName("JohnDoe");
        user.setEmail("john.doe@example.com");

        when(userRepository.findByUserId(1)).thenReturn(Optional.of(user));

        UserResponse userResponse = userService.getUserById(1);

        assertNotNull(userResponse);
        assertEquals("1", userResponse.getUserId());
        assertEquals("JohnDoe", userResponse.getUserName());
        assertEquals("john.doe@example.com", userResponse.getEmail());
    }

    @Test
    public void testCreateUser() {
        UserRequest userRequest = new UserRequest();
        userRequest.setUserName("JohnDoe");
        userRequest.setPassword("password");
        userRequest.setConfirmPassword("password");
        userRequest.setEmail("john.doe@example.com");

        User user = new User();
        user.setUserId(1);
        user.setUserName("JohnDoe");
        user.setEmail("john.doe@example.com");

        when(userRepository.save(any(User.class))).thenReturn(user);

        UserResponse userResponse = userService.createUser(userRequest);

        assertNotNull(userResponse);
        assertEquals(1, userResponse.getUserId());
        assertEquals("JohnDoe", userResponse.getUserName());
        assertEquals("john.doe@example.com", userResponse.getEmail());
    }

    @Test
    public void testUpdateUserById() {
    	 User user = new User();
         user.setUserId(1);

         UserAddressRequest userAddressRequest = new UserAddressRequest();
         UserRequest userRequest = new UserRequest();
         List<UserAddressRequest> addressRequests = new ArrayList<>();
         addressRequests.add(userAddressRequest);
         userRequest.setUserAddress(addressRequests);

         UserAddress userAddress = new UserAddress();
         userAddress.setUserId(user);

         UserResponse userResponse = new UserResponse();
         UserAddressResponse userAddressResponse = new UserAddressResponse();
         
         when(userRepository.findByUserId(1)).thenReturn(Optional.of(user));
         //when(objectMapper.convertValue(userAddressRequest, UserAddress.class)).thenReturn(userAddress);
        // when(objectMapper.convertValue(user, UserResponse.class)).thenReturn(userResponse);
         when(objectMapper.convertValue(userAddress, UserAddressResponse.class)).thenReturn(userAddressResponse);

         UserResponse result = userService.updateUserById(1, userRequest);

         assertNotNull(result);
         assertEquals(1, result.getUseraddresses().size());
         verify(userAddressRepo, times(1)).save(userAddress);
    }
}
