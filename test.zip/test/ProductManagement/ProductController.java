package com.ECommerceProject.ProductManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ECommerceProject.ProductManagement.entity.Category;
import com.ECommerceProject.ProductManagement.entity.Product;

import com.ECommerceProject.ProductManagement.repo.ICategoryRepository;

import com.ECommerceProject.ProductManagement.repo.IProductRepository;
import com.ECommerceProject.ProductManagement.request.ProductRequest;
import com.ECommerceProject.ProductManagement.response.ProductResponse;
import com.ECommerceProject.ProductManagement.service.ProductServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProductController {

    @Mock
    private IProductRepository productRepository;

    @Mock
    private ICategoryRepository categoryRepo;

   

    @InjectMocks
    private ProductServiceImpl productService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateProduct() {
        ProductRequest productRequest = new ProductRequest();
        productRequest.setName("Test Product");
        productRequest.setPrice(BigDecimal.valueOf(100));
        productRequest.setCategory(new Category());

       

        Product product = new Product();
        product.setName("Test Product");
        product.setPrice(BigDecimal.valueOf(100));
        product.setCategory(new Category());
        product.setProductCode(2);

        when(productRepository.save(any(Product.class))).thenReturn(product);

        ProductResponse productResponse = productService.createProduct(productRequest);

        assertNotNull(productResponse);
        assertEquals("Test Product", productResponse.getName());
        assertEquals(2, productResponse.getProductCode());
    }

    @Test
    public void testGetProductWithFilter() {
        ProductRequest productRequest = new ProductRequest();
        productRequest.setName("Test Product");
        productRequest.setMinPrice(BigDecimal.valueOf(50));
        productRequest.setMaxPrice(BigDecimal.valueOf(150));

        Product product = new Product();
        product.setName("Test Product");
        product.setPrice(BigDecimal.valueOf(100));
        product.setCategory(new Category());

        when(productRepository.findAll()).thenReturn(Collections.singletonList(product));

        ProductResponse productResponse = productService.getProductWithFilter(productRequest);

        assertNotNull(productResponse);
        assertEquals("Test Product", productResponse.getName());
    }

    @Test
    public void testGetProductById() {
        Product product = new Product();
        product.setProductCode(1);
        product.setName("Test Product");
        product.setActive(true);

        when(productRepository.findByProductCode(1)).thenReturn(Optional.of(product));

        ProductResponse productResponse = productService.getProductById(1);

        assertNotNull(productResponse);
        assertEquals("Test Product", productResponse.getName());
    }

    @Test
    public void testUpdateProductByCode() {
        ProductRequest productRequest = new ProductRequest();
        productRequest.setName("Updated Product");
        productRequest.setPrice(BigDecimal.valueOf(150));

        Product product = new Product();
        product.setProductCode(1);
        product.setName("Test Product");
        product.setActive(true);

        when(productRepository.findByProductCode(1)).thenReturn(Optional.of(product));
        when(productRepository.save(any(Product.class))).thenReturn(product);

        ProductResponse productResponse = productService.updateProductByCode(1, productRequest);

        assertNotNull(productResponse);
        assertEquals("Updated Product", productResponse.getName());
    }

    @Test
    public void testDeleteByProductId() {
        Product product = new Product();
        product.setProductCode(1);
        product.setName("Test Product");
        product.setActive(true);

        when(productRepository.findByProductCode(1)).thenReturn(Optional.of(product));

        String response = productService.deleteByProductId(1);

        assertEquals("Product Deleted Sucessfully", response);
        assertFalse(product.isActive());
    }
}