package com.ECommerceProject.OrderManagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ECommerceProject.OrderManagement.entity.OrderCodeSequence;
import com.ECommerceProject.OrderManagement.entity.OrderItem;
import com.ECommerceProject.OrderManagement.entity.Orders;
import com.ECommerceProject.OrderManagement.repository.IOrderCodeSequenceRepository;
import com.ECommerceProject.OrderManagement.repository.IOrderRepository;
import com.ECommerceProject.OrderManagement.request.OrderItemRequest;
import com.ECommerceProject.OrderManagement.request.OrderRequest;
import com.ECommerceProject.OrderManagement.response.OrderResponse;
import com.ECommerceProject.OrderManagement.service.OrderServiceSimpl;
import com.ECommerceProject.UserManagement.entity.User;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OrderControllerTest {

    @Mock
    private IOrderRepository orderRepository;

    @Mock
    private IOrderCodeSequenceRepository orderCodeRepo;

    @InjectMocks
    private OrderServiceSimpl orderService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateOrder() {
        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setUser(new User());
        orderRequest.setOrderDate(new Date());
        orderRequest.setStatus("Pending");
        orderRequest.setTotalAmount(100.0);
        orderRequest.setOrderItems(Collections.singletonList(new OrderItemRequest()));

        OrderCodeSequence sequence = new OrderCodeSequence();
        sequence.setCurrentCount(1L);
        when(orderCodeRepo.findById(1)).thenReturn(Optional.of(sequence));

        Orders order = new Orders();
        order.setOrderId("PROD-2");
        order.setUser(new User());
        order.setOrderDate(new Date());
        order.setStatus("Pending");
        order.setTotalAmount(100.0);
        order.setOrderItems(Collections.singletonList(new OrderItem()));

        when(orderRepository.save(any(Orders.class))).thenReturn(order);

        OrderResponse orderResponse = orderService.createOrder(orderRequest);

        assertNotNull(orderResponse);
        assertEquals("PROD-2", orderResponse.getOrderId());
        assertEquals("Pending", orderResponse.getStatus());
    }

    @Test
    public void testGetOrderById() {
        Orders order = new Orders();
        order.setOrderId("PROD-1");
        order.setStatus("Pending");

        when(orderRepository.findByOrderId("PROD-1")).thenReturn(Optional.of(order));

        OrderResponse orderResponse = orderService.getOrderById("PROD-1");

        assertNotNull(orderResponse);
        assertEquals("PROD-1", orderResponse.getOrderId());
        assertEquals("Pending", orderResponse.getStatus());
    }

    @Test
    public void testUpdateOrderById() {
        Orders order = new Orders();
        order.setOrderId("PROD-1");
        order.setStatus("Pending");

        when(orderRepository.findByOrderId("PROD-1")).thenReturn(Optional.of(order));

        OrderResponse orderResponse = orderService.updateOrderById("PROD-1", "Shipped");

        assertNotNull(orderResponse);
        assertEquals("PROD-1", orderResponse.getOrderId());
        assertEquals("Shipped", orderResponse.getStatus());
    }

    @Test
    public void testGetAllOrders() {
        Orders order = new Orders();
        order.setOrderId("PROD-1");
        order.setStatus("Pending");

        when(orderRepository.findByUser_UserId("1")).thenReturn(Optional.of(Collections.singletonList(order)));

        List<OrderResponse> orderResponses = orderService.getAllOrders("1");

        assertNotNull(orderResponses);
        assertFalse(orderResponses.isEmpty());
        assertEquals("PROD-1", orderResponses.get(0).getOrderId());
    }
}