package com.ECommerceProject.ShipmentManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ECommerceProject.OrderManagement.entity.Orders;
import com.ECommerceProject.ShipmentManagement.entity.Shipment;
import com.ECommerceProject.ShipmentManagement.repository.IShipmentRepository;
import com.ECommerceProject.ShipmentManagement.request.ShipmentRequest;
import com.ECommerceProject.ShipmentManagement.response.ShipmentResponse;
import com.ECommerceProject.ShipmentManagement.service.ShipmentServiceImp;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ShipmentControllerTest {

    @Mock
    private IShipmentRepository shipmentRepo;

    @InjectMocks
    private ShipmentServiceImp shipmentService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateShipment() {
        ShipmentRequest shipmentRequest = new ShipmentRequest();
        shipmentRequest.setOrderId(new Orders());
        shipmentRequest.setCarrier("Carrier");
        shipmentRequest.setTrackingNumber("123456");
        shipmentRequest.setStatus("Shipped");
        shipmentRequest.setShippedAt(new Date());
        shipmentRequest.setExpectedDelivery(new Date());

        Shipment shipment = new Shipment();
        shipment.setOrderId(new Orders());
        shipment.setCarrier("Carrier");
        shipment.setTrackingNumber("123456");
        shipment.setStatus("Shipped");
        shipment.setShippedAt(new Date());
        shipment.setExpectedDelivery(new Date());

        when(shipmentRepo.save(any(Shipment.class))).thenReturn(shipment);

        ShipmentResponse shipmentResponse = shipmentService.createShipment(shipmentRequest);

        assertNotNull(shipmentResponse);
        assertEquals("Carrier", shipmentResponse.getCarrier());
        assertEquals("123456", shipmentResponse.getTrackingNumber());
    }

    @Test
    public void testTrackShipment() {
        Shipment shipment = new Shipment();
        shipment.setOrderId(new Orders());
        shipment.setCarrier("Carrier");
        shipment.setTrackingNumber("123456");
        shipment.setStatus("Shipped");

        when(shipmentRepo.findByOrderId_OrderId("1")).thenReturn(Optional.of(shipment));

        ShipmentResponse shipmentResponse = shipmentService.trackShipment("1");

        assertNotNull(shipmentResponse);
        assertEquals("Carrier", shipmentResponse.getCarrier());
        assertEquals("123456", shipmentResponse.getTrackingNumber());
    }

    @Test
    public void testUpdateShipment() {
        Shipment shipment = new Shipment();
        shipment.setOrderId(new Orders());
        shipment.setCarrier("Carrier");
        shipment.setTrackingNumber("123456");
        shipment.setStatus("Shipped");

        when(shipmentRepo.findByOrderId_OrderId("1")).thenReturn(Optional.of(shipment));

        ShipmentResponse shipmentResponse = shipmentService.updateShipment("1", "Delivered");

        assertNotNull(shipmentResponse);
        assertEquals("Delivered", shipmentResponse.getStatus());
    }
}