package com.ECommerceProject.PaymentManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ECommerceProject.OrderManagement.entity.Orders;
import com.ECommerceProject.PaymentManagement.entity.PaymentTransaction;
import com.ECommerceProject.PaymentManagement.repository.IPaymentRepository;
import com.ECommerceProject.PaymentManagement.request.PaymentRequest;
import com.ECommerceProject.PaymentManagement.response.PaymentResponse;
import com.ECommerceProject.PaymentManagement.service.PaymentServiceImp;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PaymentControllerTest {

    @Mock
    private IPaymentRepository paymentRepo;

    @InjectMocks
    private PaymentServiceImp paymentService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testProcessPayment() {
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setOrderId(new Orders());
        paymentRequest.setPaymentGateway("Gateway");
        paymentRequest.setAmount(BigDecimal.valueOf(100));
        paymentRequest.setCurrency("USD");
        paymentRequest.setStatus("Success");
        paymentRequest.setErrorDetails(null);

        PaymentTransaction payment = new PaymentTransaction();
        payment.setOrderId(new Orders());
        payment.setPaymentGateway("Gateway");
        payment.setAmount(BigDecimal.valueOf(100));
        payment.setCurrency("USD");
        payment.setStatus("Success");
        payment.setErrorDetails(null);

        when(paymentRepo.save(any(PaymentTransaction.class))).thenReturn(payment);

        PaymentResponse paymentResponse = paymentService.processPayment(paymentRequest);

        assertNotNull(paymentResponse);
        assertEquals("Gateway", paymentResponse.getPaymentGateway());
        assertEquals(BigDecimal.valueOf(100), paymentResponse.getAmount());
    }

    @Test
    public void testGetPaymentStatusByOrderId() {
        PaymentTransaction payment = new PaymentTransaction();
        payment.setOrderId(new Orders());
        payment.setPaymentGateway("Gateway");
        payment.setAmount(BigDecimal.valueOf(100));
        payment.setCurrency("USD");
        payment.setStatus("Success");
        payment.setErrorDetails(null);

        when(paymentRepo.findByOrderId_OrderId("1")).thenReturn(Optional.of(payment));

        PaymentResponse paymentResponse = paymentService.getPaymentStatusByOrderId("1");

        assertNotNull(paymentResponse);
        assertEquals("Gateway", paymentResponse.getPaymentGateway());
        assertEquals(BigDecimal.valueOf(100), paymentResponse.getAmount());
    }
}
