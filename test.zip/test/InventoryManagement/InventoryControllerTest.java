package com.ECommerceProject.InventoryManagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import com.ECommerceProject.InventoryManagement.entity.Inventory;
import com.ECommerceProject.InventoryManagement.entity.InventoryLog;
import com.ECommerceProject.InventoryManagement.repo.IInventoryRepository;
import com.ECommerceProject.InventoryManagement.request.InventoryRequest;
import com.ECommerceProject.InventoryManagement.response.InventoryResponse;
import com.ECommerceProject.InventoryManagement.service.InventoryServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

public class InventoryControllerTest {

    @Mock
    private IInventoryRepository inventoryRepo;

    @InjectMocks
    private InventoryServiceImpl inventoryService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetProductQuantity() {
        Inventory inventory = new Inventory();
        inventory.setStockLevel(100);

        when(inventoryRepo.findByProduct_ProductCode("PROD-1")).thenReturn(Optional.of(inventory));

        InventoryResponse inventoryResponse = inventoryService.getProductQuantity("PROD-1");

        assertNotNull(inventoryResponse);
        assertEquals(100, inventoryResponse.getStockLevel());
    }

    @Test
    public void testUpdateProductQuantity() {
        Inventory inventory = new Inventory();
        inventory.setStockLevel(100);

        InventoryRequest inventoryRequest = new InventoryRequest();
        inventoryRequest.setStockLevel(150);

        when(inventoryRepo.findByProduct_ProductCode("PROD-1")).thenReturn(Optional.of(inventory));

        // Mocking SecurityContextHolder to return a mock authentication
        Authentication authentication = mock(Authentication.class);
        UserDetails userDetails = mock(UserDetails.class);
        when(userDetails.getUsername()).thenReturn("testUser");
        when(authentication.getPrincipal()).thenReturn(userDetails);
        when(SecurityContextHolder.getContext().getAuthentication()).thenReturn(authentication);

        InventoryResponse inventoryResponse = inventoryService.updateProductQuantity("PROD-1", inventoryRequest);

        assertNotNull(inventoryResponse);
        assertEquals(150, inventoryResponse.getStockLevel());
    }
}
